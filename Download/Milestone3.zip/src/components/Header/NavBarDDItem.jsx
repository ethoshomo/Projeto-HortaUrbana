import React from 'react'

function NavBarDDItem(){
    return (
        <>
            <li><Link className="dropdown-item" to="/carrinho">Carrinho</Link></li>
        </>
    )
}

export default NavBarDDItem