import React from 'react'

function FooterPolitics() {
    return (
        <div className="p-2 bd-highlight footer-box">
            <h4>Políticas</h4>
            <p>Política de Atendimento ao Consumidor</p>
            <p>Política de Trocas e Devoluções</p>
        </div>
    )
}
export default FooterPolitics