import React from 'react'

function Copyright(){
    return (
        <footer className="copyright">
            <small>_HortaUrbana - Copyright 2023 - Todos os direitos reservados</small>
        </footer>
    )
}

export default Copyright