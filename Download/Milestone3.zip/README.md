# RECURSOS DO PROJETO

* HTML5
* JavaScript ECMA6+
* SASS
* CSS3
* Bootstrap 5.1
* React JS
* Node.js