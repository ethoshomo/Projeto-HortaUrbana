import React from 'react'

function CartShipping() {
    return (
        <>
            <h5 className='board-title'>Frete</h5>
            <p className='board-text text-center'>Valor único: R$ 5,00</p>
            <hr />
        </>
    )
}

export default CartShipping