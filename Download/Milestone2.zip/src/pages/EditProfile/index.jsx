import React from 'react'
import FormEditarCad from './FormEditProfile'

function Editar() {

    return (
        <section id="paginaCadProdutos" className="boxContent">
            
            <h1>Editar Cadastro</h1>
            
            <article id="form-edit-profile">
                <FormEditarCad />
            </article>
            
        </section>
    )
}

export default Editar